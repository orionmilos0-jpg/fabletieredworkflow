# Run State — current tiered-workflow run

A durable, append-only log for the run in progress. Every tier updates it so the
**reviewer** and the architect's final eval can see the whole run at a glance
instead of reconstructing it from chat history and worker narratives. Keep it
boring and factual — it's a checklist, not prose.

How it's used:

- The **architect** resets this file to a fresh run section at plan time.
- Each **worker** appends an entry when it finishes — or when it stops blocked —
  covering: what changed, tests run + result, what's still broken, what's next.
- The **reviewer** reads this file first, then the diff. The verdict is recorded
  at the bottom (the orchestrator writes it, since the reviewer stays read-only).
- This holds the CURRENT run only. Durable history lives in git commits (and, if
  you use Codex, the saved `reviews/`). Reset or archive between runs as you like;
  it's fine to gitignore this file.

---

## Run: <YYYY-MM-DD HH:MM> — <short goal>

### Plan (architect)

- **Goal:** <one line>
- **Packages:**
  - `PKG-…` — <title> — tier: developer
  - `PKG-…` — <title> — tier: test-writer
- **Open questions:** none  *(if any exist, resolve them before routing — see the Definition of Ready in HANDOFF-TEMPLATE.md)*

### Worker log

<!-- Append one block per worker completion. Newest at the bottom. -->

#### <timestamp> · <agent> · `PKG-…`

- **Changed:** `path/one` — <one line>; `path/two` — <one line>
- **Tests:** `<command>` → <pass/fail counts>
- **Still broken:** <or "nothing">
- **Next:** <hand to which tier / ready for review / done>

### Reviewer verdict

- **Status:** <approve / approve-with-nits / changes-required>
- **Blockers:** <numbered, file:line + fix — or "none">
- **Codex findings:** <adjudicated: accepted → blockers/nits, or dismissed with reason>
- **Recorded by:** orchestrator
